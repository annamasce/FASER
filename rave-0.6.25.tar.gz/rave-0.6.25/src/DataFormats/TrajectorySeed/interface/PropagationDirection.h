#ifndef dataFormats_PropagationDirection_H
#define dataFormats_PropagationDirection_H

enum PropagationDirection {oppositeToMomentum, alongMomentum, anyDirection};

#endif 
