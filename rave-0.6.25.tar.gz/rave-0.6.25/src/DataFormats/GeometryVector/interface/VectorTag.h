#ifndef VectorTag_H
#define VectorTag_H

class VectorTag{};

#endif // VectorTag_H
