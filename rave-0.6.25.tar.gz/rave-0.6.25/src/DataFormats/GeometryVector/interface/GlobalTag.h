#ifndef _GlobalTag_H_
#define _GlobalTag_H_

class GlobalTag{};

#endif // GlobalTag_H
