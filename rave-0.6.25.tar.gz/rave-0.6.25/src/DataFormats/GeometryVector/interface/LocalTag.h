#ifndef LocalTag_H
#define LocalTag_H

class LocalTag{};

#endif // LocalTag_H
