#ifndef PointTag_H
#define PointTag_H

class PointTag{};

#endif // PointTag_H
