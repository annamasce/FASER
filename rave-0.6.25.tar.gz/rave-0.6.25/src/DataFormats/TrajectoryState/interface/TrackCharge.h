#ifndef _TrackCharge_H_
#define _TrackCharge_H_

typedef int   TrackCharge;

#endif 
