#ifndef BTauReco_JetTagFwd_h
#define BTauReco_JetTagFwd_h

/** Rave's JetTagFwd version
  *
  */

namespace reco {
  class JetTag;
  typedef JetTag * JetTagRef;
}

#endif
