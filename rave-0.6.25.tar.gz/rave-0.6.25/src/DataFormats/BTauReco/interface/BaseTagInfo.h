#ifndef DataFormats_BTauReco_BaseTagInfo_h
#define DataFormats_BTauReco_BaseTagInfo_h

namespace reco {
 
class BaseTagInfo {
};

}

#endif // DataFormats_BTauReco_BaseTagInfo_h
