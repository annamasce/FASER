#ifndef RefMacros_h
#define RefMacros_h

#define DECLARE_EDM_REFS( class_name ) ;

#endif
