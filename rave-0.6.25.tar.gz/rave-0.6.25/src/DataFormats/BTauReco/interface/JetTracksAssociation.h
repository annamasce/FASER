#ifndef DataFormats_JetTracksAssociation_H
#define DataFormats_JetTracksAssociation_H

namespace reco
{
  typedef int JetTracksAssociation;
  typedef int JetTracksAssociationRef;
}

#endif
