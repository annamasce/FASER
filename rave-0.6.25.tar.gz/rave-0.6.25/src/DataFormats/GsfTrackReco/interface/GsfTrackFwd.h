#ifndef GsfTrackReco_GsfTrackFwd_h
#define GsfTrackReco_GsfTrackFwd_h

namespace reco {
  class GsfTrack;
  /// persistent reference to a GsfTrackExtra
  typedef const GsfTrack * GsfTrackRef;
}

#endif
