#ifndef GsfTrackReco_GsfTrackExtraFwd_h
#define GsfTrackReco_GsfTrackExtraFwd_h

namespace reco {
  class GsfTrackExtra;
  /// persistent reference to a GsfTrackExtra
  typedef const GsfTrackExtra * GsfTrackExtraRef;
}

#endif
