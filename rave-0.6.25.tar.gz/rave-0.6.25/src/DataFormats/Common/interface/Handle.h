#ifndef Framework_Handle_H
#define Framework_Handle_H

namespace edm {
template < class T > class ESHandle  {
};
}

#endif
