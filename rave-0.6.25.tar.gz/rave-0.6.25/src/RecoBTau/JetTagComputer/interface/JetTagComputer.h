#ifndef RecoBTau_JetTagComputer_h
#define RecoBTau_JetTagComputer_h

class JetTagComputer {
};

#endif
